function execute() {
    return Response.success([
        {title: "玄幻小说", input: "https://www.duanqingsi.com/fenlei/1/1/", script: "zen.js"},
        {title: "奇幻小说", input: "https://www.duanqingsi.com/fenlei/2/1/", script: "zen.js"},
        {title: "武侠小说", input: "https://www.duanqingsi.com/fenlei/3/1/", script: "zen.js"},
        {title: "仙侠小说", input: "https://www.duanqingsi.com/fenlei/4/1/", script: "zen.js"},
        {title: "都市小说", input: "https://www.duanqingsi.com/fenlei/5/1/", script: "zen.js"},
        {title: "军事小说", input: "https://www.duanqingsi.com/fenlei/6/1/", script: "zen.js"},
        {title: "历史小说", input: "https://www.duanqingsi.com/fenlei/7/1/", script: "zen.js"},
        {title: "游戏小说", input: "https://www.duanqingsi.com/fenlei/8/1/", script: "zen.js"},
        {title: "竞技小说", input: "https://www.duanqingsi.com/fenlei/9/1/", script: "zen.js"},
        {title: "科幻小说", input: "https://www.duanqingsi.com/fenlei/10/1/", script: "zen.js"},
        {title: "悬疑小说", input: "https://www.duanqingsi.com/fenlei/11/1/", script: "zen.js"}
    ]);
}