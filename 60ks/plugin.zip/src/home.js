function execute() {
    return Response.success([
        {title: "玄幻", input: 'http://www.60ks.cc/bookstore/xuanhuan/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "仙侠", input: 'http://www.60ks.cc/bookstore/xianxia/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "都市", input: 'http://www.60ks.cc/bookstore/dushi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "军史", input: 'http://www.60ks.cc/bookstore/lishi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "悬疑", input: 'http://www.60ks.cc/bookstore/xuanyi/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "网游", input: 'http://www.60ks.cc/bookstore/wangyou/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "科幻", input: 'http://www.60ks.cc/bookstore/kehuan/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "灵异", input: 'http://www.60ks.cc/bookstore/chuanyue/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "穿越", input: 'http://www.60ks.cc/bookstore/tongren/default-0-0-0-0-0-0-', script: "gen.js"},
        {title: "同人", input: 'http://www.60ks.cc/bookstore/jingsong/default-0-0-0-0-0-0-', script: "gen.js"}
    ]);
}