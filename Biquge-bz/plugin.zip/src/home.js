function execute() {
    return Response.success([
        {title: "首页", input: "https://www.biquge.bz/", script: "gen.js"},
        {title: "玄幻魔法", input: "http://www.biquge.bz/xuanhuan.html", script: "gen.js"},
        {title: "都市言情", input: "https://www.biquge.bz/dushi.html", script: "gen.js"},
        {title: "武侠修真", input: "https://www.biquge.bz/wuxia.html", script: "gen.js"},
        {title: "历史军事", input: "https://www.biquge.bz/lishi.html", script: "gen.js"},
        {title: "恐怖科幻", input: "https://www.biquge.bz/kehuan.html", script: "gen.js"},
        {title: "网游同人", input: "https://www.biquge.bz/wangyou.html", script: "gen.js"},
        {title: "完本小说", input: "https://www.biquge.bz/wanben.html", script: "gen.js"},
    ]);
}