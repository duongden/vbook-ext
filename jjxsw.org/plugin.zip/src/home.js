function execute() {
    return Response.success([
        {title: "武侠", input:  "https://www.jjxsw.org/sort/wuxiaxianxia/1/", script: "gen.js"},
        {title: "言情", input:  "https://www.jjxsw.org/sort/yanqing/1/", script: "gen.js"},
        {title: "玄幻", input:  "https://www.jjxsw.org/sort/xuanhuan/1/", script: "gen.js"},
        {title: "都市", input:  "https://www.jjxsw.org/sort/dushi/1/", script: "gen.js"},
        {title: "穿越", input:  "https://www.jjxsw.org/sort/chuanyue/1/", script: "gen.js"},
        {title: "科幻", input:  "https://www.jjxsw.org/sort/kehuanxiaoshuo/1/", script: "gen.js"},
        {title: "网游", input:  "https://www.jjxsw.org/sort/wangyou/1/", script: "gen.js"},
        {title: "同人", input:  "https://www.jjxsw.org/sort/tongren/1/", script: "gen.js"},
        {title: "历史", input:  "https://www.jjxsw.org/sort/lishi/1/", script: "gen.js"},
        {title: "惊悚", input:  "https://www.jjxsw.org/sort/jingsong/1/", script: "gen.js"},
        {title: "重生", input:  "https://www.jjxsw.org/sort/chongsheng/1/", script: "gen.js"},
        {title: "耽美", input:  "https://www.jjxsw.org/sort/danmei/1/", script: "gen.js"},

    ]);
}