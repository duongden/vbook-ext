function execute() {
    return Response.success([
        {title: "玄幻魔法", input:  "https://www.dongliuxiaoshuo.com/sort/xuanhuanmofa", script: "zen.js"},
        {title: "武侠修真", input:  "https://www.dongliuxiaoshuo.com/sort/wuxiaxiuzhen", script: "zen.js"},
        {title: "都市言情", input:  "https://www.dongliuxiaoshuo.com/sort/dushiyanqing", script: "zen.js"},
        {title: "历史军事", input:  "https://www.dongliuxiaoshuo.com/sort/lishijunshi", script: "zen.js"},
        {title: "网游动漫", input:  "https://www.dongliuxiaoshuo.com/sort/wangyoudongman", script: "zen.js"},
        {title: "科幻小说", input:  "https://www.dongliuxiaoshuo.com/sort/kehuanxiaoshuo", script: "zen.js"},
        {title: "恐怖灵异", input:  "https://www.dongliuxiaoshuo.com/sort/kongbulingyi", script: "zen.js"},
        {title: "其他类型", input:  "https://www.dongliuxiaoshuo.com/sort/qita", script: "zen.js"}

    ]);
}