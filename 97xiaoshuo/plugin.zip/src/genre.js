function execute() {
    return Response.success([
        { title: "玄幻小说", input: "https://www.97xiaoshuo.net/xuanhuanxiaoshuo/", script: "zen.js" },
        { title: "修真小说", input: "https://www.97xiaoshuo.net/xiuzhenxiaoshuo/", script: "zen.js" },
        { title: "都市小说", input: "https://www.97xiaoshuo.net/dushixiaoshuo/", script: "zen.js" },
        { title: "历史小说", input: "https://www.97xiaoshuo.net/chuanyuexiaoshuo/", script: "zen.js" },
        { title: "网游小说", input: "https://www.97xiaoshuo.net/wangyouxiaoshuo/", script: "zen.js" },
        { title: "科幻小说", input: "https://www.97xiaoshuo.net/kehuanxiaoshuo/", script: "zen.js" },
        { title: "其它小说", input: "https://www.97xiaoshuo.net/qitaxiaoshuo/", script: "zen.js" }
    ]);
}