function execute() {
    return Response.success([
        {title: "武侠", input:  "http://www.ijjxsw.net/html/wuxiaxianxia/1.html", script: "gen.js"},
        {title: "言情", input:  "http://www.ijjxsw.net/html/yanqing/1.html", script: "gen.js"},
        {title: "玄幻", input:  "http://www.ijjxsw.net/html/xuanhuan/1.html", script: "gen.js"},
        {title: "都市", input:  "http://www.ijjxsw.net/html/dushi/1.html", script: "gen.js"},
        {title: "穿越", input:  "http://www.ijjxsw.net/html/chuanyue/1.html", script: "gen.js"},
        {title: "科幻", input:  "http://www.ijjxsw.net/html/kehuanxiaoshuo/1.html", script: "gen.js"},
        {title: "网游", input:  "http://www.ijjxsw.net/html/wangyou/1.html", script: "gen.js"},
        {title: "同人", input:  "http://www.ijjxsw.net/html/tongren/1.html", script: "gen.js"},
        {title: "历史", input:  "http://www.ijjxsw.net/html/lishi/1.html", script: "gen.js"},
        {title: "惊悚", input:  "http://www.ijjxsw.net/html/jingsong/1.html", script: "gen.js"},
        {title: "重生", input:  "http://www.ijjxsw.net/html/chongsheng/1.html", script: "gen.js"},
        {title: "耽美", input:  "http://www.ijjxsw.net/html/danmei/1.html", script: "gen.js"},

    ]);
}