function execute() {
    return Response.success([
        {title: "玄幻", input: "/sort/xuanhuan/", script: "zen.js"},
        {title: "仙侠", input: "/sort/xianxia/", script: "zen.js"},
        {title: "都市", input: "/sort/dushi/", script: "zen.js"},
        {title: "历史", input: "/sort/lishi/", script: "zen.js"},
        {title: "游戏", input: "/sort/youxi/", script: "zen.js"},
        {title: "科幻", input: "/sort/kehuan/", script: "zen.js"},
        {title: "耽美", input: "/sort/nvsheng/", script: "zen.js"},
        {title: "综合", input: "/sort/qita/", script: "zen.js"}
    ]);
}