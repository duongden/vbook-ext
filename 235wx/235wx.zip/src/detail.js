function execute(url) {
    url = url.replace('m.235wx.com', 'www.235wx.com');
    let response = fetch(url);
    if (response.ok) {

        let doc = response.html();
        let coverImg = doc.select('meta[property="og:image"]').attr("content");
        let descriptionMeta = doc.select('meta[property="og:description"]').attr("content");
        let title = doc.select('meta[property="og:title"]').attr("content");
        let status = doc.select('meta[property="og:novel:status"]').attr("content");
        let newUpdate = doc.select('meta[property="og:novel:update_time"]').attr("content");
        let author = doc.select('meta[property="og:novel:author"]').attr("content");
        let category = doc.select('meta[property="og:novel:category"]').attr("content");

        if (coverImg.startsWith("/")) {
            coverImg = "https://www.235wx.com" + coverImg;
        }
        return Response.success({
            name: title,
            cover: coverImg,
            author: author,
            description: ("<br>Thể loại: <br>") + category + ("<br>⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀<br>") + "Tình trạng: " + status + ("<br>⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀<br>") + descriptionMeta,
            detail: "作者：" + author + ("<br>⠀⠀⠀⠀⠀⠀⠀⠀<br>") + "Mới nhất: " + newUpdate,
            host: "https://www.235wx.com"
        });
    }
    return null;
}