function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
       console.log(url)
        let el = doc.select("#list > dl > a[rel='chapter']")
        const data = [];
        for (let i = 12; i < el.size(); i++) {
            var e = el.get(i);
            data.push({
                name: e.select("a").text(),
                url: e.attr("href"),
                host: "https://www.235wx.com"
            })
        }
        return Response.success(data);
    }
    return null;
}

//     if (response.ok) {
//         let doc = response.html();
//         const data = [];
//         doc.select("#list > dl > a[rel='chapter']")
//                for (let i = 0;i < doc.size(); i++) {
//             let e = doc.get(i);
//         data.push({
//             name: e.select("a").text(),
//             url: e.attr("href"),
//             host: "https://www.235wx.com"
//         }));
//         return Response.success(data);
//     }
//     return null;
// }