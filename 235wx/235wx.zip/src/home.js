function execute() {
    return Response.success([
        {title: "首页", input: "https://www.235wx.com/", script: "gen.js"}
    ]);
}