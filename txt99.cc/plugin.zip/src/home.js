function execute() {
    return Response.success([
        {title: "武侠", input:  "http://www.txt99.cc/list/wuxiaxianxia/1/", script: "gen.js"},
        {title: "言情", input:  "http://www.txt99.cc/list/yanqing/1/", script: "gen.js"},
        {title: "玄幻", input:  "http://www.txt99.cc/list/xuanhuan/1/", script: "gen.js"},
        {title: "都市", input:  "http://www.txt99.cc/list/dushi/1/", script: "gen.js"},
        {title: "穿越", input:  "http://www.txt99.cc/list/chuanyue/1/", script: "gen.js"},
        {title: "科幻", input:  "http://www.txt99.cc/list/kehuanxiaoshuo/1/", script: "gen.js"},
        {title: "网游", input:  "http://www.txt99.cc/list/wangyou/1/", script: "gen.js"},
        {title: "同人", input:  "http://www.txt99.cc/list/tongren/1/", script: "gen.js"},
        {title: "历史", input:  "http://www.txt99.cc/list/lishi/1/", script: "gen.js"},
        {title: "惊悚", input:  "http://www.txt99.cc/list/jingsong/1/", script: "gen.js"},
        {title: "重生", input:  "http://www.txt99.cc/list/chongsheng/1/", script: "gen.js"},
        {title: "耽美", input:  "http://www.txt99.cc/list/danmei/1/", script: "gen.js"},

    ]);
}