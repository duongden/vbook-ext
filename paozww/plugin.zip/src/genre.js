function execute() {
    return Response.success([
        {title: "玄幻魔法", input: "https://www.paozww.com/sort/1/1/", script: "zen.js"},
        {title: "武侠修真", input: "https://www.paozww.com/sort/2/1/", script: "zen.js"},
        {title: "都市言情", input: "https://www.paozww.com/sort/3/1/", script: "zen.js"},
        {title: "历史军事", input: "https://www.paozww.com/sort/4/1//", script: "zen.js"},
        {title: "穿越架空", input: "https://www.paozww.com/sort/5/1/", script: "zen.js"},
        {title: "游戏竞技", input: "https://www.paozww.com/sort/6/1/", script: "zen.js"},
        {title: "科幻灵异", input: "https://www.paozww.com/sort/7/1/", script: "zen.js"},
    ]);
}