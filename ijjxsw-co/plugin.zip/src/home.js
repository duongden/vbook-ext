function execute() {
    return Response.success([
        {title: "穿越小说", input:  "http://www.ijjxsw.co/class/chuanyue/1/", script: "gen.js"},
        {title: "言情小说", input:  "http://www.ijjxsw.co/class/yanqing/1/", script: "gen.js"},
        {title: "现代都市", input:  "http://www.ijjxsw.co/class/dushi/1/", script: "gen.js"},
        {title: "历史架空", input:  "http://www.ijjxsw.co/class/lishi/1/", script: "gen.js"},
        {title: "美文同人", input:  "http://www.ijjxsw.co/class/tongren/1/", script: "gen.js"},
        {title: "武侠仙侠", input:  "http://www.ijjxsw.co/class/wuxia/1/", script: "gen.js"},
        {title: "玄幻小说", input:  "http://www.ijjxsw.co/class/xuanhuan/1/", script: "gen.js"},
        {title: "惊悚悬疑", input:  "http://www.ijjxsw.co/class/jingsong/1/", script: "gen.js"},
        {title: "科幻小说", input:  "http://www.ijjxsw.co/class/kehuan/1/", script: "gen.js"},
        {title: "网游竞技", input:  "http://www.ijjxsw.co/class/wangyou/1/", script: "gen.js"},     
    ]);
}