let BASE_URL = 'https://comiconlinefree.me';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}