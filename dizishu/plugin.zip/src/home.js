function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "1", script: "gen.js" },
        { title: "武侠仙侠", input: "1", script: "gen.js" },
        { title: "都市娱乐", input: "1", script: "gen.js" },
        { title: "历史军事", input: "1", script: "gen.js" },
        { title: "科幻灵异", input: "1", script: "gen.js" },
        { title: "女生言情", input: "1", script: "gen.js" },
        { title: "N次元", input: "1", script: "gen.js" },
        { title: "其他类型", input: "1", script: "gen.js" },
        { title: "完本小说", input: "1", script: "gen.js" },     
    ]);
}
