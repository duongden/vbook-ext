function execute() {
    return Response.success([
        {title: "最近更新", input: "https://www.youyoukanshu.com/", script: "gen.js"}
    ]);
}