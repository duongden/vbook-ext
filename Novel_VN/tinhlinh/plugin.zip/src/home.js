function execute() {
    return Response.success([
        { title: "Sủng", input: "https://tinhlinh.com/ngon-tinh-sung", script: "gen.js" },
        { title: "Ngược", input: "https://tinhlinh.com/ngon-tinh-nguoc", script: "gen.js" },
        { title: "Nữ tôn", input: "https://tinhlinh.com/nu-ton", script: "gen.js" },
        { title: "Cung đấu", input: "https://tinhlinh.com/cung-dau", script: "gen.js" },
        { title: "Bách Hợp", input: "https://tinhlinh.com/bach-hop", script: "gen.js" },
        { title: "Đam mỹ", input: "https://tinhlinh.com/dam-my", script: "gen.js" },
        { title: "Điền văn", input: "https://tinhlinh.com/dien-van", script: "gen.js" },
        { title: "Dị thế", input: "https://tinhlinh.com/di-the", script: "gen.js" },
        { title: "Xuyên không", input: "https://tinhlinh.com/xuyen-khong", script: "gen.js" },
        { title: "Trùng sinh", input: "https://tinhlinh.com/trung-sinh", script: "gen.js" },
        { title: "Đồng nhân", input: "https://tinhlinh.com/dong-nhan", script: "gen.js" },
        { title: "Huyền huyễn", input: "https://tinhlinh.com/huyen-huyen", script: "gen.js" },
        { title: "Khác", input: "https://tinhlinh.com/khac", script: "gen.js" }
    ])
}
