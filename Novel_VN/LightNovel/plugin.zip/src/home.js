function execute() {
    return Response.success([
        { title: "Truyện dịch", input: "https://lnvn.net/truyen-dich", script: "gen.js" },
        { title: "Convert", input: "https://lnvn.net/convert", script: "gen.js" },
        { title: "Sáng tác", input: "https://lnvn.net/sang-tac", script: "gen.js" },
        { title: "Romance", input: "https://lnvn.net/genre/romance", script: "gen.js" },
        { title: "Fantasy", input: "https://lnvn.net/genre/fantasy", script: "gen.js" },
        { title: "Comedy", input: "https://lnvn.net/genre/comedy", script: "gen.js" },
        { title: "Action", input: "https://lnvn.net/genre/action", script: "gen.js" },
        { title: "Drama", input: "https://lnvn.net/genre/drama", script: "gen.js" },
        { title: "Adventure", input: "https://lnvn.net/genre/adventure", script: "gen.js" },
        { title: "School Life", input: "https://lnvn.net/genre/school-life", script: "gen.js" },
        { title: "Slice of Life", input: "https://lnvn.net/genre/slice-of-life", script: "gen.js" },
        { title: "Web Novel", input: "https://lnvn.net/genre/web-novel", script: "gen.js" },
        { title: "Harem", input: "https://lnvn.net/genre/harem", script: "gen.js" },
        { title: "Supernatural", input: "https://lnvn.net/genre/supernatural", script: "gen.js" },
        { title: "Isekai", input: "https://lnvn.net/genre/isekai", script: "gen.js" },
        { title: "Ecchi", input: "https://lnvn.net/genre/ecchi", script: "gen.js" },
        { title: "Shounen", input: "https://lnvn.net/genre/shounen", script: "gen.js" },
        { title: "Tragedy", input: "https://lnvn.net/genre/tragedy", script: "gen.js" },
        { title: "Mystery", input: "https://lnvn.net/genre/mystery", script: "gen.js" },
        { title: "Psychological", input: "https://lnvn.net/genre/psychological", script: "gen.js" },
        { title: "Adapted to Manga", input: "https://lnvn.net/genre/adapted-to-manga", script: "gen.js" },
        { title: "Magic", input: "https://lnvn.net/genre/magic", script: "gen.js" },
        { title: "Mature", input: "https://lnvn.net/genre/mature", script: "gen.js" }
    ])
}
