function execute(url) {
    var doc = Http.get(url).html();
    var el = doc.select("#tab-b0 > div > ul > li a");
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push({
            name: e.select("a span").text().trim(),
            url: e.attr("href"),
            host: "https://lnvn.net"
        })
    }

    return Response.success(data);
}

// function execute(url) {
//     let response = fetch(url);
//     if (response.ok) {
//         let doc = response.html();
//         doc.select("#tab-b0").remove();
// //#tab-b1 > div.chapters
//         let list = [];
//         //#tab-b0 > div > ul > li:nth-child(1) > a
//         doc.select("#tab-b0 > div > ul > li > a").forEach(e => list.push({
//             name: e.text("a").remove(".pull-right"),
//             url: e.attr("href").trim(),
//                 host: "https://lnvn.net"
//         }));
//         return Response.success(list);

//     }
//     return null;
// }