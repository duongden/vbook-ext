//    var host = 'https://www.69shuba.com';
let BASE_URL = 'https://69shuba.cx';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}