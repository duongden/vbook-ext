function execute() {
    return Response.success([
        {title: "重生耽美", input: "http://www.2kshu.cc/chongsheng/", script: "zen.js"},
        {title: "古代耽美", input: "http://www.2kshu.cc/guyan/", script: "zen.js"},   
        {title: "耽美宠文", input: "http://www.2kshu.cc/chongwen/", script: "zen.js"},
        {title: "经典耽美", input: "http://www.2kshu.cc/qingchun/", script: "zen.js"},
        {title: "虐心耽美", input: "http://www.2kshu.cc/nvexin/", script: "zen.js"},
        {title: "校园耽美", input: "http://www.2kshu.cc/xiaoyuan/", script: "zen.js"},
        {title: "强强耽美", input: "http://www.2kshu.cc/qiangqiang/", script: "zen.js"},
        {title: "言情总裁", input: "http://www.2kshu.cc/yanqing/", script: "zen.js"}
    ]);
}