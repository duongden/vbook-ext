function execute() {
    return Response.success([
        {title: "首页", input: "http://www.shukw.com/", script: "gen.js"}
    ]);
}