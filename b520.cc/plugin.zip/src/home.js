function execute() {
    return Response.success([
        {title: "首页", input: "http://www.b520.cc/", script: "gen.js"},
        {title: "玄幻小说", input: "http://www.b520.cc/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "修真小说", input: "http://www.b520.cc/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市小说", input: "http://www.b520.cc/dushixiaoshuo/", script: "gen.js"},
        {title: "穿越小说", input: "http://www.b520.cc/chuanyuexiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.b520.cc/wangyouxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.b520.cc/kehuanxiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "http://www.b520.cc/yanqingxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "http://www.b520.cc/tongrenxiaoshuo/", script: "gen.js"}

    ]);
}