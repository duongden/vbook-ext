function execute() {
    return Response.success([
        {title: "首页", input: "http://www.ibiquge.la/", script: "gen.js"},
        {title: "玄幻小说", input: "https://www.ibiquge.la/xuanhuanxiaoshuo/", script: "gen.js"},
        {title: "修真小说", input: "https://www.ibiquge.la/xiuzhenxiaoshuo/", script: "gen.js"},
        {title: "都市小说", input: "https://www.ibiquge.la/dushixiaoshuo/", script: "gen.js"},
        {title: "穿越小说", input: "https://www.ibiquge.la/chuanyuexiaoshuo/", script: "gen.js"},
        {title: "网游小说", input: "https://www.ibiquge.la/wangyouxiaoshuo/", script: "gen.js"},
        {title: "科幻小说", input: "https://www.ibiquge.la/kehuanxiaoshuo/", script: "gen.js"}                

    ]);
}