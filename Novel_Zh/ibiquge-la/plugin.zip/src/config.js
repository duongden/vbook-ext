let BASE_URL = 'http://www.xbiqugu.la';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}