function execute(url) {
    url = url.replace('m.ibiquge.la', 'www.ibiquge.la');
    let response = fetch(url);
    if (response.ok) {
        console.log("blacktea");
        let doc = response.html();
        let coverImg = doc.select('meta[property="og:image"]').attr("content");
        let author = doc.select('meta[property="og:novel:author"]').attr("content");
        let category = doc.select('meta[property="og:novel:category"]').attr("content");
       // let updateTime = doc.select('meta[property="og:novel:update_time"]').attr("content").replace(/\d\d:\d\d:\d\d/g, "");
        let descriptionMeta = doc.select('meta[property="og:description"]').attr("content").replace("    ","<br>");

        if (coverImg.startsWith("/")) {
            coverImg = "http://www.ibiquge.la" + coverImg;
        }
//#info > p:nth-child(5)

        return Response.success({
            name: doc.select("#info h1").text(),
            cover: coverImg,
            author: author,
            description: ("Thể loại: ") + category + '<br>' + doc.select("#info > p:nth-child(5)").text()  + '<br>' + doc.select("#info > p:nth-child(4)").text().replace(/\d\d:\d\d:\d\d/g, "") + '<br>' + descriptionMeta,
            detail: "Tác giả: " + author,
            host: "http://www.ibiquge.la"
        });
    }
    return null;
}