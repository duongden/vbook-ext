function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let htm = doc.select("#content p.content_detail").html();
        htm = cleanHtml(htm);
        return Response.success(htm);
    }
    return null;
}
function cleanHtml(html) {
    //xoá rác
    html = html.replace("天才一秒记住本站地址：[ 笔趣阁]","");
    html = html.replace("https://www.9biqu.com最快更新！无广告！","");
    html = html.replace("看小说上www,9biqu.com","");
    html = html.replace("一秒记住http：//m.9biqu.com", '');
    html = html.replace("记住网址ｍ.9bｉqu．ｃom", '');
    html = html.replace("一秒记住www.9biqu.com", '');
    html = html.replace("最新章节！", '');
    html = html.replace("笔趣阁", '');
    html = html.replace("首发尽在www.9biqu。com", '');

    // replace p tags with empty string
    html = html.replace(/<\/?p>/g, "");
    // replace a tags with empty string
    html = html.replace(/<a[^>]*>([^<]+)<\/a>/g, '');
    // replace new line characters with br tags
    html = html.replace(/\n/g, '<br>');
    // remove duplicate br tags
    html = html.replace(/(<br>\s*){2,}/gm, '<br>');
    // strip html comments
    html = html.replace(/<!--[^>]*-->/gm, '');
    // html decode
    html = html.replace(/&(nbsp|amp|quot|lt|gt);/g, "");
    // trim br tags
    html = html.replace(/(^(\s*<br>\s*)+|(<br>\s*)+$)/gm, '');
    return html.trim();
}