function execute() {
    return Response.success([
        {title: "玄幻", input: "/class/1/", script: "zen.js"},
        {title: "武侠", input: "/class/2/", script: "zen.js"},
        {title: "都市", input: "/class/3/", script: "zen.js"},
        {title: "历史", input: "/class/4/", script: "zen.js"},
        {title: "科幻", input: "/class/5/", script: "zen.js"},
        {title: "游戏", input: "/class/6/", script: "zen.js"},
        {title: "女生", input: "/class/7/", script: "zen.js"},
        {title: "其他", input: "/class/8/", script: "zen.js"}
    ]);
}