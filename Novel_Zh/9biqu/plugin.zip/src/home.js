function execute() {
    return Response.success([
        { title: "首页", input: "https://www.9biqu.com/", script: "gen.js" }

    ]);
}