function execute() {
    return Response.success([
        {title: "最近更新", input: "https://www.bifengzw.com/", script: "gen.js"}
    ]);
}