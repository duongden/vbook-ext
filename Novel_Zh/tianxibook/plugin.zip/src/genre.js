function execute() {
    return Response.success([
        { title: "玄幻", input: "/fenlei/", script: "zen.js" },
        { title: "奇幻", input: "/fenlei/2/", script: "zen.js" },
        { title: "武侠", input: "/fenlei/3/", script: "zen.js" },
        { title: "仙侠", input: "/fenlei/4/", script: "zen.js" },
        { title: "都市", input: "/fenlei/5/", script: "zen.js" },
        { title: "历史", input: "/fenlei/6/", script: "zen.js" },
        { title: "军事", input: "/fenlei/7/", script: "zen.js" },
        { title: "游戏", input: "/fenlei/8/", script: "zen.js" },
        { title: "体育", input: "/fenlei/9/", script: "zen.js" },
        { title: "科幻", input: "/fenlei/10/", script: "zen.js" },
        { title: "灵异", input: "/fenlei/1", script: "zen.js" },
        { title: "古代", input: "/fenlei/12/", script: "zen.js" },
        { title: "现代", input: "/fenlei/13/", script: "zen.js" },
        { title: "玄幻", input: "/fenlei/14/", script: "zen.js" },
        { title: "仙侠", input: "/fenlei/15/", script: "zen.js" },
        { title: "浪漫", input: "/fenlei/16/", script: "zen.js" },
        { title: "游戏", input: "/fenlei/17/", script: "zen.js" },
        { title: "科幻", input: "/fenlei/18/", script: "zen.js" },
        { title: "悬疑", input: "/fenlei/19/", script: "zen.js" },
        { title: "二次", input: "/fenlei/20/", script: "zen.js" },
        { title: "其他", input: "/fenlei/2", script: "zen.js" }
    ]);
}
