function execute() {
    return Response.success([
        {title: "首页", input: "https://www.kygnew.com", script: "gen.js"},
        {title: "玄幻", input: "https://www.kygnew.com/xuanhuan/", script: "gen.js"},
        {title: "修真", input: "https://www.kygnew.com/xiuzhen/", script: "gen.js"},
        {title: "都市", input: "https://www.kygnew.com/dushi/", script: "gen.js"},
        {title: "历史", input: "https://www.kygnew.com/lishi/", script: "gen.js"},
        {title: "网游", input: "https://www.kygnew.com/wangyou/", script: "gen.js"},
        {title: "科幻", input: "https://www.kygnew.com/kehuan/", script: "gen.js"},
        {title: "言情", input: "https://www.kygnew.com/yanqing/", script: "gen.js"},
        {title: "其他", input: "https://www.kygnew.com/qita/", script: "gen.js"},
        {title: "全本", input: "https://www.kygnew.com/quanben/", script: "gen.js"}   
    ]);
}