function execute() {
    return Response.success([
        { title: "首页", input: "https://www.97xiaoshuo.net/", script: "gen.js" }
    ]);
}