function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "/xuanhuanxiaoshuo/1_", script: "zen.js" },
        { title: "修真仙侠", input: "/xiuzhenxiaoshuo/2_", script: "zen.js" },
        { title: "都市青春", input: "/dushixiaoshuo/3_", script: "zen.js" },
        { title: "历史军事", input: "/lishixiaoshuo/4_", script: "zen.js" },
        { title: "网游竞技", input: "/wangyouxiaoshuo/5_", script: "zen.js" },
        { title: "科幻灵异", input: "/kehuanxiaoshuo/6_", script: "zen.js" },
        { title: "其它小说", input: "/qitaxiaoshuo/7_", script: "zen.js" },
        { title: "全本小说", input: "/wanben/1_", script: "zen.js" },
    ]);
}