let BASE_URL = 'http://www.ibiquzw.info';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}