function execute(key, page) {
    let response = fetch('https://www.ijjxsw.co/search/', {
        method: "POST",
        queries: {
            searchkey: key,
            //mysearch
        }
    });

    if (response.ok) {
        let doc = response.html();
        const data = [];

        doc.select(".listbg").forEach(e => {
            data.push({
                name: e.select(".title a").first().text(),
                link: e.select(".title a").first().attr("href"),
                cover: e.select(".img").attr("src"),
                description: e.select(".newDate").first().text().replace(/\//g, "").trim(),
                host: "https://www.ijjxsw.co"
            })
        });

        return Response.success(data);
    }
    return null;
}
// name: e.select(".s2 a").first().text(),
// cover: "https://raw.githubusercontent.com/duongden/vbook/main/nocover.png",
// link: e.select(".s2 a").first().attr("href"),
// description: e.select(".s3 a").first().text(),
// host: BASE_URL,