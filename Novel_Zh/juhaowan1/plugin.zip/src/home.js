function execute() {
    return Response.success([
        { title: "书库", input: "http://www.juhaowan.club/all.html", script: "gen.js" },
        { title: "日榜", input: "http://www.juhaowan.club/other/rank_hits/order/hits_day.html", script: "zen.js" },
        { title: "周榜", input: "http://www.juhaowan.club/other/rank_hits/order/hits_week.html", script: "zen.js" },
        { title: "月榜", input: "http://www.juhaowan.club/other/rank_hits/order/hits_month.html", script: "zen.js" },
        { title: "总榜", input: "http://www.juhaowan.club/other/rank_hits/order/hits.html", script: "zen.js" },
    ]);
}