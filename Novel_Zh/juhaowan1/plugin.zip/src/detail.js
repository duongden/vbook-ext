function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let coverImg = doc.select("div.fl.detailgame > div.pic.fl > span > img").first().attr("src");
        if (coverImg.startsWith("/")) {
            coverImg = "http://www.juhaowan.club/" + coverImg;
        }
        let author = doc.select(".brief a.author").first().text();
        return Response.success({
            name: doc.select(".brief .title span.name").text(),
            cover: coverImg,
            author: author,
            description: "Thể loại: " + doc.select("div.brief.fl > div.tags.clearfixer > a:nth-child(2) > span").text() + "<br>" + "Tình trạng: " + doc.select(".brief .tags span.isfinish").text() + "<br>" + "Mới nhất: " + doc.select(".newchapter .title .chaptername a").text() + "<br>" + doc.select(".summary pre").text().replace("    ",'/\n'),
            detail: "Tác giả: " + author,
            host: "http://www.juhaowan.club"
        });
    }
    return null;
}
//div.brief.fl > div.tags.clearfixer > a:nth-child(2) > span