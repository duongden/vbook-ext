function execute(key) {
    let response = fetch('http://www.juhaowan.club/search.html?keyword=', {
        method: "GET",
        queries: {
            keyword: key,
        }
    });

    if (response.ok) {
        let doc = response.html();
        const data = [];
        var next = doc.select(".pagination > li.active + li").last().text();
        doc.select(".secd-rank-list dl").forEach(e => {
            data.push({
                name: e.select("dl > dd > a").first().text(),
                link: e.select("dl > dd > a").first().attr("href"),
                cover: e.select("dt img.lazyimg").attr("data-original"),
                description: e.select("p span").first().text(),
                host: "http://www.juhaowan.club"
            })
        });

        return Response.success(data, next);
    }
    return null;
}
// function execute(key, page) {
//     if (!page) page = '1';
//     const doc = Http.get('http://www.juhaowan.club/search.html?keyword=').params({
//         listType : 'pagination',
//         page : page,
//         name : key,
//     }).html();

//     var next = doc.select(".pagination").select("li:has(a.active) + li").text()
//     const el = doc.select(".secd-rank-list dl")
//     const data = [];
//     for (var i = 0; i < el.size(); i++) {
//         var e = el.get(i);
//         data.push({
//                 name: e.select("dl > dd > a").first().text(),
//                 link: e.select("dl > dd > a").first().attr("href"),
//                 cover: e.select("dt img.lazyimg").attr("data-original"),
//                 description: e.select("p span").first().text(),
//             host: "http://www.juhaowan.club"
//         })
//     }
//     return Response.success(data, next)
// }