function execute(url,page) {
    if (!page) page = '1';
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        const data = [];
        doc.select("dd a span").remove();
        doc.select(".secd-rank-list dl").forEach(e => {
            data.push({
                name: e.select("dd a.bigpic-book-name").first().text(),
                link: e.select("dd a").first().attr("href"),
                over: e.select("dt img").first().attr("data-original"),
                description: e.select("dd p a.red").text(),
                host: "http://www.juhaowan.club"
            })
        });
        return Response.success(data)
    }
    return null;
}