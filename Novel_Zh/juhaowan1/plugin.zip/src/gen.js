function execute(url,page) {
    if (!page) page = '1';
    let response = fetch(url + "?page=" + page);
    console.log(url + "?page=" + page)
    if (response.ok) {
        let doc = response.html();
        const data = [];
        var next = doc.select(".pagination > li.active + li").last().text();
        doc.select(".listboxw dl").forEach(e => {
            data.push({
                name: e.select("dd a").first().text(),
                link: e.select("dd a").first().attr("href"),
                over: e.select("dt img").first().attr("data-original"),
                description: e.select("dd > p:nth-child(2)").text().replace(/\|/g, '-'),
                host: "http://www.juhaowan.club"
            })
        });
        return Response.success(data, next)
    }
    return null;
}