function execute(url) {
    const data = [];
    data.push({
        name: "0",
        url: url,
        host: "http://wd.juhaowan.club"
    })
    return Response.success(data);
}