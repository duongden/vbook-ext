function execute() {
    return Response.success([
        { title: "问答", input: "http://wd.juhaowan.club", script: "gen.js" }
    ]);
}