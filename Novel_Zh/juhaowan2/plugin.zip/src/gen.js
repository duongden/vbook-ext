// function execute(url,page) {
//     if (!page) page = '0';
//     let response = fetch(url + "/page/" + page + "/");
//     if (response.ok) {
//         let doc = response.html();
//         const data = [];
//         var next = doc.select('a[title*="下一页"]').last().attr("href").split(/[_ ]+/).pop();
//         doc.select("div.article-panel").forEach(e => {
//             data.push({
//                 name: e.select("h3.title a").first().text(),
//                 link: e.select("h3.title a").first().attr("href"),
//                 description: e.select("div.a-meta span.float-left.d-none.d-md-block span").first().text(),
//                 host: "http://wd.juhaowan.club"
//             })
//         });
//         return Response.success(data, next)
//     }
//     return null;
// }

function execute(url, page) {
    if (!page) page = '1';
    let response = fetch(url + "/page/" + page + "/");
    if (response.ok) {
        let doc = response.html();
        const data = [];
        doc.select("div.article-panel").forEach(e => {
            data.push({
                name: e.select("h3.title a").first().text(),
                link: e.select("h3.title a").first().attr("href"),
                description: e.select("div.a-meta span.float-left.d-none.d-md-block span").first().text(),
                host: "http://wd.juhaowan.club"
            })
        });
        let next = doc.select(".paginations").select("span.current + a").first().text();
        return Response.success(data, next)
    }
    return null;
}