function execute() {
    return Response.success([
        {title: "玄幻魔法", input: "/xclass/1/", script: "zen.js"},
        {title: "武侠修真", input: "/xclass/2/", script: "zen.js"},
        {title: "都市言情", input: "/xclass/3/", script: "zen.js"},
        {title: "历史军事", input: "/xclass/4/", script: "zen.js"},
        {title: "侦探推理", input: "/xclass/5/", script: "zen.js"},
        {title: "网游动漫", input: "/xclass/6/", script: "zen.js"},
        {title: "科幻小说", input: "/xclass/7/", script: "zen.js"},
        {title: "恐怖灵异", input: "/xclass/8/", script: "zen.js"},
        {title: "女生小说", input: "/xclass/9/", script: "zen.js"},
        {title: "其它小说", input: "/xclass/10/", script: "zen.js"}
    ]);
}