function execute() {
    return Response.success([
        {title: "首页", input: "https://wap.ebookbao.org", script: "gen.js"}
    ]);
}