function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "https://www.jnwx.org/fl/xuanhuan/", script: "zen.js" },
        { title: "武侠仙侠", input: "https://www.jnwx.org/fl/wuxia/", script: "zen.js" },
        { title: "都市生活", input: "https://www.jnwx.org/fl/dushi/", script: "zen.js" },
        { title: "历史军事", input: "https://www.jnwx.org/fl/lishi/", script: "zen.js" },
        { title: "游戏竞技", input: "https://www.jnwx.org/fl/youxi/", script: "zen.js" },
        { title: "科幻未来", input: "https://www.jnwx.org/fl/kehuan/", script: "zen.js" },
        { title: "恐怖悬疑", input: "https://www.jnwx.org/fl/xuanyi/", script: "zen.js" },
        { title: "古代言情", input: "https://www.jnwx.org/fl/guyan/", script: "zen.js" },
        { title: "现代言情", input: "https://www.jnwx.org/fl/xianyan/", script: "zen.js" },
        { title: "幻想奇缘", input: "https://www.jnwx.org/fl/huanqing/", script: "zen.js" },
        { title: "游戏情缘", input: "https://www.jnwx.org/fl/zongcai/", script: "zen.js" },
        { title: "浪漫青春", input: "https://www.jnwx.org/fl/qingchun/", script: "zen.js" },
        { title: "言情美文", input: "https://www.jnwx.org/fl/wangluo/", script: "zen.js" }
    ]);
}