function execute() {
    return Response.success([
        { title: "首页", input: "https://www.ddyueshu.com/", script: "gen.js" }
    ]);
}