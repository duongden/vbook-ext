function execute() {
    return Response.success([
        { title: "玄幻", input: "/dusort1/", script: "zen.js" },
        { title: "武侠", input: "/dusort2/", script: "zen.js" },
        { title: "都市", input: "/dusort3/", script: "zen.js" },
        { title: "历史", input: "/dusort4/", script: "zen.js" },
        { title: "网游", input: "/dusort5/", script: "zen.js" },
        { title: "科幻", input: "/dusort6/", script: "zen.js" },
        { title: "女生", input: "/dusort7/", script: "zen.js" },
        { title: "全本", input: "/dusort9/", script: "zen.js" }
    ]);
}