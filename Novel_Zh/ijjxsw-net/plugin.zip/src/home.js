function execute() {
    return Response.success([
        { title: "穿越", input: "http://www.ijjjxs.net/html/chuanyue/", script: "gen.js" },
        { title: "言情", input: "http://www.ijjjxs.net/html/yanqing/", script: "gen.js" },
        { title: "现代都市", input: "http://www.ijjjxs.net/html/dushi/1/", script: "gen.js" },
        { title: "耽美百合", input: "http://www.ijjjxs.net/html/baihe/", script: "gen.js" },
        { title: "历史架空", input: "http://www.ijjjxs.net/html/lishi/", script: "gen.js" },
        { title: "美文同人", input: "http://www.ijjjxs.net/html/tongren/", script: "gen.js" },
        { title: "武侠仙侠", input: "http://www.ijjjxs.net/html/wuxia/", script: "gen.js" },
        { title: "玄幻", input: "http://www.ijjjxs.net/html/xuanhuan/", script: "gen.js" },
        { title: "惊悚悬疑", input: "http://www.ijjjxs.net/html/jingsong/", script: "gen.js" },
        { title: "科幻", input: "http://www.ijjjxs.net/html/kehuan/", script: "gen.js" },
        { title: "网游竞技", input: "http://www.ijjjxs.net/html/wangyou/", script: "gen.js" },
        { title: "管理哲学", input: "http://www.ijjjxs.net/html/zhexue/", script: "gen.js" },
        { title: "学习资料", input: "http://www.ijjjxs.net/html/ziliao/", script: "gen.js" },
    ]);
}