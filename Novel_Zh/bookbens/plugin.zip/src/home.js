function execute() {
    return Response.success([
        {title: "首页", input: "http://www.bookbens.com/", script: "gen.js"}
    ]);
}