function execute() {
    return Response.success([
        {title: "玄幻", input: "/class/xuanhuan/", script: "zen.js"},
        {title: "修真", input: "/class/xiuzhen/", script: "zen.js"},
        {title: "都市", input: "/class/dushi/", script: "zen.js"},
        {title: "穿越", input: "/class/chuanyue/", script: "zen.js"},
        {title: "网游", input: "/class/wangyou/", script: "zen.js"},
        {title: "科幻", input: "/class/kehuan/", script: "zen.js"},
        {title: "其他", input: "/class/qita/", script: "zen.js"}
    ]);
}

/* <li><a href="/class/xuanhuan/1/">玄幻</a></li>
<li><a href="/class/xiuzhen/1/">修真</a></li>
<li><a href="/class/dushi/1/">都市</a></li>
<li><a href="/class/chuanyue/1/">穿越</a></li>
<li><a href="/class/wangyou/1/">网游</a></li>
<li><a href="/class/kehuan/1/">科幻</a></li>
<li><a href="/class/qita/1/">其他</a></li> */