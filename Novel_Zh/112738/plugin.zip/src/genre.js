function execute() {
    return Response.success([
        {title: "玄幻", input:  "https://www.112378.com/class/xuanhuan/", script: "zen.js"},
        {title: "都市", input:  "https://www.112378.com/class/dushi/", script: "zen.js"},
        {title: "武侠", input:  "https://www.112378.com/class/wuxia/", script: "zen.js"},
        {title: "耽美", input:  "https://www.112378.com/class/danmei/", script: "zen.js"},
        {title: "科幻", input:  "https://www.112378.com/class/kehuan/", script: "zen.js"},
        {title: "轻小", input:  "https://www.112378.com/class/lightnovel/", script: "zen.js"},
        {title: "历史", input:  "https://www.112378.com/class/lishi/", script: "zen.js"},
        {title: "言情", input:  "https://www.112378.com/class/yanqing/", script: "zen.js"}

    ]);
}