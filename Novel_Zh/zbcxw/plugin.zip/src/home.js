function execute() {
    return Response.success([
        { title: "近期更新", input: "/fenlei/0_0_0_0_0_", script: "gen.js" }
    ]);
}
