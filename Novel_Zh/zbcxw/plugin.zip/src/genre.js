function execute() {
    return Response.success([
        { title: "穿越重生", input: "/fenlei/1_0_0_0_0_", script: "gen.js" },
        { title: "仙侠奇缘", input: "/fenlei/2_0_0_0_0_", script: "gen.js" },
        { title: "浪漫青春", input: "/fenlei/3_0_0_0_0_", script: "gen.js" },
        { title: "架空历史", input: "/fenlei/4_0_0_0_0_", script: "gen.js" },
        { title: "游戏竞技", input: "/fenlei/5_0_0_0_0_", script: "gen.js" },
        { title: "科幻空间", input: "/fenlei/6_0_0_0_0_", script: "gen.js" },
        { title: "悬疑推理", input: "/fenlei/7_0_0_0_0_", script: "gen.js" },
        { title: "综合其他", input: "/fenlei/8_0_0_0_0_", script: "gen.js" }
    ]);
}
