function execute() {
    return Response.success([
        {title: "玄幻·奇幻", input: "http://www.dubuxiaoshuo.com/nav/xh-qh-", script: "zen.js"},
        {title: "科幻·游戏", input: "http://www.dubuxiaoshuo.com/nav/kh-yx-", script: "zen.js"},
        {title: "仙侠·武侠", input: "http://www.dubuxiaoshuo.com/nav/xx-wx-", script: "zen.js"},
        {title: "女生·言情", input: "http://www.dubuxiaoshuo.com/nav/ns-yq-", script: "zen.js"},
        {title: "都市·娱乐", input: "http://www.dubuxiaoshuo.com/nav/ds-yl-", script: "zen.js"},
        {title: "历史·军事", input: "http://www.dubuxiaoshuo.com/nav/ls-js-", script: "zen.js"},
        {title: "悬疑·灵异", input: "http://www.dubuxiaoshuo.com/nav/xy-ly-", script: "zen.js"},
        {title: "耽美·纯爱", input: "http://www.dubuxiaoshuo.com/nav/dm-ca-", script: "zen.js"},
        {title: "成长·励志", input: "http://www.dubuxiaoshuo.com/nav/cz-lz-", script: "zen.js"},
        {title: "散文·随笔", input: "http://www.dubuxiaoshuo.com/nav/sw-sb-", script: "zen.js"},
        {title: "轻小说", input: "http://www.dubuxiaoshuo.com/nav/qxs-", script: "zen.js"},
        {title: "国外文学", input: "http://www.dubuxiaoshuo.com/nav/gwwx-", script: "zen.js"},
        {title: "文学名著", input: "http://www.dubuxiaoshuo.com/nav/wxmz-", script: "zen.js"},
        {title: "现当代文学", input: "http://www.dubuxiaoshuo.com/nav/xddwx-", script: "zen.js"}
    ]);
}


