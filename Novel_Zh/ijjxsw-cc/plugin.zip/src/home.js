function execute() {
    return Response.success([
        {title: "首页", input: "/", script: "zen.js"}
    ]);
}