function execute() {
    return Response.success([
        {title: "武侠", input: "/wuxiaxianxia/", script: "zen.js"},
        {title: "言情", input: "/yanqing/", script: "zen.js"},
        {title: "玄幻", input: "/xuanhuan/", script: "zen.js"},
        {title: "都市", input: "/dushi/", script: "zen.js"},
        {title: "穿越", input: "/chuanyue/", script: "zen.js"},
        {title: "科幻", input: "/kehuanxiaoshuo/", script: "zen.js"},
        {title: "网游", input: "/wangyou/", script: "zen.js"},
        {title: "同人", input: "/tongren/", script: "zen.js"},
        {title: "历史", input: "/lishi/", script: "zen.js"},
        {title: "惊悚", input: "/jingsong/", script: "zen.js"},
        {title: "重生", input: "/chongsheng/", script: "zen.js"},
        {title: "耽美", input: "/danmei/", script: "zen.js"}

    ]);
}