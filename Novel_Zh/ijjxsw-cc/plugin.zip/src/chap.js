function execute(url) {
    url = url.replace('m.ijjxsw.cc', 'www.ijjxsw.cc');
    let data  ="";
    let part1 = url.replace("http://www.ijjxsw.cc", "").replace("http://m.ijjxsw.cc", "").replace(".html","");
    var next = part1;
    while (next.includes(part1)) {
        console.log(next)
        let response = fetch("http://www.ijjxsw.cc" + next +".html");
        if (response.ok) {
            let doc = response.html();
            next = doc.select("a#next_url").attr("href").replace(".html","");
console.log(next)
            doc.select("div a").remove();
            let htm = doc.select("#booktxt").html();
            htm = cleanHtml(htm)
            data = data + htm;
        } else {
            break;
        }
    }
    if (data) {
        return Response.success(data);
    }
    return null;
}

function cleanHtml(html) {
    html = html.replace(/\n/g, '<br>');
    // remove duplicate br tags
    html = html.replace(/(<br>\s*){2,}/gm, '<br>');
    // strip html comments
    html = html.replace(/<!--[^>]*-->/gm, '');
    // html decode
    html = html.replace(/&nbsp;/g, '');
    // trim br tags
    html = html.replace(/(^(\s*<br>\s*)+|(<br>\s*)+$)/gm, '');

    return html.trim();
}