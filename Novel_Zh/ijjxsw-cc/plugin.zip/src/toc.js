function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
       console.log(url)
        let el = doc.select("#list > dl > a[rel='chapter']")
        const data = [];
        for (let i = 9; i < el.size(); i++) {
            var e = el.get(i);
            data.push({
                name: e.select("a").text(),
                url: e.attr("href"),
                host: "http://www.ijjxsw.cc"
            })
        }
        return Response.success(data);
    }
    return null;
}