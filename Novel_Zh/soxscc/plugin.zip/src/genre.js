function execute() {
    return Response.success([
        { title: "玄幻", input: "/xuanhuan/", script: "zen.js" },
        { title: "武侠", input: "/wuxia/", script: "zen.js" },
        { title: "都市", input: "/dushi/", script: "zen.js" },
        { title: "历史", input: "/lishi/", script: "zen.js" },
        { title: "游戏", input: "/youxi/", script: "zen.js" },
        { title: "科幻", input: "/kehuan/", script: "zen.js" },
        { title: "恐怖", input: "/xuanyi/", script: "zen.js" },
        { title: "其他", input: "/qita/", script: "zen.js" },
        { title: "古代", input: "/guyan/", script: "zen.js" },
        { title: "现代", input: "/xianyan/", script: "zen.js" },
        { title: "幻想", input: "/huanqing/", script: "zen.js" },
        { title: "游戏", input: "/zongcai/", script: "zen.js" },
        { title: "浪漫", input: "/qingchun/", script: "zen.js" },
        { title: "言情", input: "/wangluo/", script: "zen.js" },
        { title: "科幻", input: "/mmkehuan/", script: "zen.js" },
        { title: "其他", input: "/mmqita/", script: "zen.js" },
    ]);
}
