let BASE_URL = 'https://www.74txt.cc';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}