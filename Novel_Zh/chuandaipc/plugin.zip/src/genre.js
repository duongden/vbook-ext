function execute() {
    return Response.success([
        {title: "玄幻小说", input:  "https://www.chuandaipc.com/sort/1/1/", script: "zen.js"},
        {title: "仙侠小说", input:  "https://www.chuandaipc.com/sort/2/1/", script: "zen.js"},
        {title: "都市小说", input:  "https://www.chuandaipc.com/sort/3/1/", script: "zen.js"},
        {title: "历史军事", input:  "https://www.chuandaipc.com/sort/4/1/", script: "zen.js"},
        {title: "游戏竞技", input:  "https://www.chuandaipc.com/sort/5/1/", script: "zen.js"},
        {title: "科幻小说", input:  "https://www.chuandaipc.com/sort/6/1/", script: "zen.js"},
        {title: "恐怖小说", input:  "https://www.chuandaipc.com/sort/7/1/", script: "zen.js"},
        {title: "其他类型", input:  "https://www.chuandaipc.com/sort/8/1/", script: "zen.js"}

    ]);
}