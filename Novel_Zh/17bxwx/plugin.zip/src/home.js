function execute() {
    return Response.success([
        { title: "首页", input: "https://www.17bxwx.com/", script: "gen.js" }

    ]);
}