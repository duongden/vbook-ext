function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "/bsort1/", script: "zen.js" },
        { title: "武侠仙侠", input: "/bsort2/", script: "zen.js" },
        { title: "都市生活", input: "/bsort3/", script: "zen.js" },
        { title: "历史军事", input: "/bsort4/", script: "zen.js" },
        { title: "游戏竞技", input: "/bsort5/", script: "zen.js" },
        { title: "科幻未来", input: "/bsort6/", script: "zen.js" },
        { title: "恐怖悬疑", input: "/bsort7/", script: "zen.js" },
        { title: "其他类型", input: "/bsort8/", script: "zen.js" },
        { title: "古代言情", input: "/bsort9/", script: "zen.js" },
        { title: "现代言情", input: "/bsort10/", script: "zen.js" },
        { title: "幻想奇缘", input: "/bsort11/", script: "zen.js" },
        { title: "游戏情缘", input: "/bsort12/", script: "zen.js" },
        { title: "浪漫青春", input: "/bsort13/", script: "zen.js" },
        { title: "言情美文", input: "/bsort14/", script: "zen.js" },
        { title: "科幻灵异", input: "/bsort15/", script: "zen.js" },
        { title: "其他类型", input: "/bsort16/", script: "zen.js" }         
    ]);
}