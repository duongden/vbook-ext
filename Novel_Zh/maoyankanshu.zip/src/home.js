function execute() {
    return Response.success([
        {title: "玄幻", input: "lejRej", script: "gen.js"},
        {title: "武侠", input: "nel5aK", script: "gen.js"},
    ]);
}