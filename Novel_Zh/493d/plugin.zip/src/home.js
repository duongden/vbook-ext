function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "/xuanhuan/", script: "gen.js" },
        { title: "武侠仙侠", input: "/wuxia/", script: "gen.js" },
        { title: "都市生活", input: "/dushi/", script: "gen.js" },
        { title: "历史军事", input: "/lishi/", script: "gen.js" },
        { title: "游戏竞技", input: "/youxi/", script: "gen.js" },
        { title: "科幻未来", input: "/kehuan/", script: "gen.js" },
        { title: "恐怖悬疑", input: "/kongbu/", script: "gen.js" },
        { title: "二次元", input: "/erciyuan/", script: "gen.js" },
        { title: "古代言情", input: "/guyan/", script: "gen.js" },
        { title: "现代言情", input: "/xianyan/", script: "gen.js" },
        { title: "幻想奇缘", input: "/huanxiang/", script: "gen.js" },
        { title: "浪漫青春", input: "/langman/", script: "gen.js" },
        { title: "网络情缘", input: "/wangluo/", script: "gen.js" },
        { title: "科幻空间", input: "/kongjian/", script: "gen.js" },
        { title: "鬼怪灵异", input: "/lingyi/", script: "gen.js" },
        { title: "N次元", input: "/nciyuan/", script: "gen.js" },
        { title: "言情美文", input: "/yanqing/", script: "gen.js" },
        { title: "其他类型", input: "/qita/", script: "gen.js" }
    ]);
}
